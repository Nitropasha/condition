package org.dzhioev.rest.practice.controller;

import org.dzhioev.rest.practice.service.FooBarInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    public MyController(FooBarInterface fooBarInterface) {
        this.fooBarInterface = fooBarInterface;
    }
    FooBarInterface fooBarInterface;

    @GetMapping("/")
    public String hello() {
        return fooBarInterface.print();
    }
}