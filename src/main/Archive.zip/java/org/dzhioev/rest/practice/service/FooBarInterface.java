package org.dzhioev.rest.practice.service;

public interface FooBarInterface {
    String print();
}
